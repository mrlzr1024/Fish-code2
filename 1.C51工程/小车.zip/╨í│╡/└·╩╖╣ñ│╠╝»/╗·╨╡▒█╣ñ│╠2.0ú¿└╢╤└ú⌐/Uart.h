#ifndef  __UART_H__
#define __UART_H__
#include<reg52.h>
extern int BluetoothGet(void);
extern void Uart() ;

#endif