#ifndef  __TURINGSERVO_H__
#define __TURINGSERVO_H__
extern  int moves1(int mod1, int angle1,int mode1 );//mod1--4逆时针 5--顺时针 angle--转的角度 mode--哪位舵机



#endif
