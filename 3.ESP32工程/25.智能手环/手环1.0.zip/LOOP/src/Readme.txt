

//*===========OLED============*//
#define OLED_MOSI 18  //D1
#define OLED_CLK 5   //D0
#define OLED_DC 16
#define OLED_CS 4
#define OLED_RESET 17
//*===========OLED============*//

//*=========I2C=============*//
static const uint8_t SDA = 23;
static const uint8_t SCL = 22;


//*======SPI=================*//
static const uint8_t SS    = 33;
static const uint8_t MOSI  = 18;
static const uint8_t MISO  = 19;
static const uint8_t SCK   = 5;