#ifndef __LEVEL_2_H
#define __LEVEL_2_H
#include "encode.h"

extern void handlePressRotate(int8_t rotation);


#endif