#ifndef __HEAR_DETECT_H
#define __HEAR_DETECT_H


#include "main.h"
#include <Wire.h>
#include <MAX30100_PulseOximeter.h>
#include <Arduino.h>


extern PulseOximeter pox;
extern void Hear_Detect_init();

#endif