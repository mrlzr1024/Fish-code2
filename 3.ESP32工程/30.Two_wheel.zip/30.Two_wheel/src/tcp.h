#ifndef __TCP_H
#define __TCP_H

#include <WiFi.h>

extern String readBuff,cmd;
extern void Task_init();

#endif