/*
 * @Author: error: git config user.name && git config user.email & please set dead value or install git
 * @Date: 2022-06-11 17:28:48
 * @LastEditors: error: git config user.name && git config user.email & please set dead value or install git
 * @LastEditTime: 2022-06-11 17:29:10
 * @FilePath: \alarm_clock5\hz.cpp
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#include "hz.h"
char daysOfTheWeek[][31]={"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六",""};

char str_model[4][20]={" 每日闹钟 ", "工作日闹钟", " 单次闹钟 ", "自定义闹钟"}; //闹钟模式字符串
