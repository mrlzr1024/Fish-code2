/*
 * @Author: error: git config user.name && git config user.email & please set dead value or install git
 * @Date: 2022-06-03 20:07:10
 * @LastEditors: error: git config user.name && git config user.email & please set dead value or install git
 * @LastEditTime: 2022-06-04 16:12:28
 * @FilePath: \alarm_clock4\hz.c
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 *
 */
#ifndef __HZ_H
#define __HZ_H
extern char daysOfTheWeek[][31];

extern char str_model[4][20]; //闹钟模式字符串

#endif // !__HZ_H
