/*
 * @Author: your name
 * @Date: 2022-03-27 22:09:50
 * @LastEditTime: 2022-03-28 13:35:03
 * @LastEditors: Please set LastEditors
 * @Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 * @FilePath: \USER\time.h
 */
#ifndef __TIME_H
#define __TIME_H

#include "stm32f10x.h"
#include "My_GPIO.H"
extern void LZR_init_PWM(int arr, int psc);

#endif


